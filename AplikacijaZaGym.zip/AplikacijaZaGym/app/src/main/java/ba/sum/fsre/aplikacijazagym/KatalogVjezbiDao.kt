package ba.sum.fsre.aplikacijazagym

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface KatalogVjezbiDao {

    @Insert
    fun insert(vjezba: KatalogVjezbi)

    @Query("SELECT * FROM katalog_vjezbi")
    fun getSveVjezbe(): List<KatalogVjezbi>
}

