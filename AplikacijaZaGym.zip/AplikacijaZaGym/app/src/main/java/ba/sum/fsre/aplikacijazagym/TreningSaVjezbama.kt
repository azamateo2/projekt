package ba.sum.fsre.aplikacijazagym

import androidx.room.Embedded
import androidx.room.Relation

data class TreningSaVjezbama(
    @Embedded val trening: Trening,
    @Relation(
        parentColumn = "trening_id",
        entityColumn = "trening_id"
    )
    val vjezbe: List<VjezbaUTreningu>
)