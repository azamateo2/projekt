package ba.sum.fsre.aplikacijazagym

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface KorisnikDao {

    @Insert
    suspend fun insert(korisnik: Korisnik)

    @Query("SELECT * FROM korisnik")
    fun getAll(): List<Korisnik>
}
