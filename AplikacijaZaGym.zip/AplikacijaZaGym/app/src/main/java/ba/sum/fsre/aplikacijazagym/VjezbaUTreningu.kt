package ba.sum.fsre.aplikacijazagym

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "vjezba_u_treningu",
    foreignKeys = [
        ForeignKey(
            entity = Trening::class,
            parentColumns = ["trening_id"],
            childColumns = ["trening_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = KatalogVjezbi::class,
            parentColumns = ["katalog_id"],
            childColumns = ["katalog_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("trening_id"), Index("katalog_id")]
)
data class VjezbaUTreningu(
    @PrimaryKey(autoGenerate = true)
    val sifra: Int = 0,
    val trening_id: Int,
    val katalog_id: Int,
    val broj_serija: Int,
    val broj_ponavljanja: Int,
    val tezina: Double
)
