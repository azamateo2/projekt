package ba.sum.fsre.aplikacijazagym

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "trening",
    foreignKeys = [
        ForeignKey(
            entity = Korisnik::class,
            parentColumns = ["korisnik_id"],
            childColumns = ["korisnik_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["korisnik_id"])]
)
data class Trening(
    @PrimaryKey(autoGenerate = true)
    val trening_id: Int = 0,

    val datum: String,
    val tip_treninga: String,
    val korisnik_id: Int
)
