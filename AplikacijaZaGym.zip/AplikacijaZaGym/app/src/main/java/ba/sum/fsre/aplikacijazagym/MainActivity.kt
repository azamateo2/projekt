package ba.sum.fsre.aplikacijazagym

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "moj_trening_db"
        ).fallbackToDestructiveMigration().build()

        val repository = FitnessRepository(db)

        val etIme = findViewById<EditText>(R.id.etIme)
        val etPrezime = findViewById<EditText>(R.id.etPrezime)
        val btnSpremi = findViewById<Button>(R.id.btnSpremi)

        btnSpremi.setOnClickListener {
            val ime = etIme.text.toString().trim()
            val prezime = etPrezime.text.toString().trim()

            if (ime.isNotEmpty() && prezime.isNotEmpty()) {
                lifecycleScope.launch(Dispatchers.IO) {
                    try {

                        val trenutniKatalog = repository.dohvatiKatalog()
                        if (trenutniKatalog.isEmpty()) {
                            repository.dodajUKatalog(KatalogVjezbi(naziv_vjezbe = "Bench Press", opis = ""))
                            repository.dodajUKatalog(KatalogVjezbi(naziv_vjezbe = "Čučanj", opis = ""))
                            repository.dodajUKatalog(KatalogVjezbi(naziv_vjezbe = "Mrtvo dizanje", opis = ""))
                        }

                        val sviKorisnici = repository.sviKorisnici()
                        var korisnik = sviKorisnici.find {
                            it.ime.equals(ime, ignoreCase = true) && it.prezime.equals(prezime, ignoreCase = true)
                        }

                        if (korisnik == null) {
                            repository.unesiKorisnika(Korisnik(ime = ime, prezime = prezime))
                            korisnik = repository.sviKorisnici().find {
                                it.ime.equals(ime, ignoreCase = true) && it.prezime.equals(prezime, ignoreCase = true)
                            }
                        }

                        withContext(Dispatchers.Main) {
                            if (korisnik != null) {
                                val intent = Intent(this@MainActivity, TreningActivity::class.java)
                                intent.putExtra("KORISNIK_ID", korisnik.id)
                                intent.putExtra("KORISNIK_IME", korisnik.ime)
                                startActivity(intent)

                                etIme.text.clear()
                                etPrezime.text.clear()
                            } else {
                                Toast.makeText(this@MainActivity, "Greška pri kreiranju korisnika", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(this@MainActivity, "Baza podataka: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                        e.printStackTrace()
                    }
                }
            } else {
                Toast.makeText(this, "Molimo unesite ime i prezime", Toast.LENGTH_SHORT).show()
            }
        }
    }
}