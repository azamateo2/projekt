package ba.sum.fsre.aplikacijazagym

class FitnessRepository(private val db: AppDatabase) {

    suspend fun unesiKorisnika(k: Korisnik) = db.korisnikDao().insert(k)
    suspend fun sviKorisnici() = db.korisnikDao().getAll()

    suspend fun dodajUKatalog(v: KatalogVjezbi) = db.katalogVjezbiDao().insert(v)
    suspend fun dohvatiKatalog() = db.katalogVjezbiDao().getSveVjezbe()

    suspend fun dodajTrening(t: Trening) = db.treningDao().insert(t)

    suspend fun zapocniTrening(t: Trening): Long = db.treningDao().insert(t)
    suspend fun spremiVjezbuUTrening(v: VjezbaUTreningu) = db.vjezbaUTreninguDao().insert(v)

    suspend fun dohvatiSveTreningeKorisnika(korisnikId: Int): List<TreningSaVjezbama> {
        return db.treningDao().getSveZaKorisnika(korisnikId)
    }
}