package ba.sum.fsre.aplikacijazagym

import androidx.room.Database
import androidx.room.RoomDatabase


@Database(
    entities = [
        Korisnik::class,
        Trening::class,
        KatalogVjezbi::class,
        VjezbaUTreningu::class
    ],
    version = 1
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun korisnikDao(): KorisnikDao
    abstract fun treningDao(): TreningDao
    abstract fun katalogVjezbiDao(): KatalogVjezbiDao
    abstract fun vjezbaUTreninguDao(): VjezbaUTreninguDao
}
