package ba.sum.fsre.aplikacijazagym

import android.os.Bundle
import android.widget.Button // OVO JE BITNO
import android.widget.TextView // OVO JE BITNO
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PovijestActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_povijest)


        val tvPodaci = findViewById<TextView>(R.id.tvPovijestPodaci)
        val btnNazad = findViewById<Button>(R.id.btnNazad)
        val korisnikId = intent.getIntExtra("KORISNIK_ID", -1)


        btnNazad.setOnClickListener {
            finish() 
        }

        // 3. DOHVAĆANJE PODATAKA IZ BAZE
        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "moj_trening_db").build()
        val repository = FitnessRepository(db)

        lifecycleScope.launch(Dispatchers.IO) {
            val listaTreninga = repository.dohvatiSveTreningeKorisnika(korisnikId)
            val katalog = repository.dohvatiKatalog()
            val sb = StringBuilder()

            if (listaTreninga.isEmpty()) {
                sb.append("Još nemaš spremljenih treninga.")
            } else {
                var posljednjiDatum = ""
                for (item in listaTreninga) {
                    if (item.trening.datum != posljednjiDatum) {
                        if (posljednjiDatum != "") sb.append("\n")
                        sb.append("📅 ${item.trening.datum}\n")
                        sb.append("━━━━━━━━━━━━━━━━━━━━\n")
                        posljednjiDatum = item.trening.datum
                    }

                    val katId = item.vjezbe.firstOrNull()?.katalog_id
                    val nazivVjezbe = katalog.find { it.katalog_id == katId }?.naziv_vjezbe ?: "Vježba"

                    sb.append("💪 $nazivVjezbe:\n")

                    for ((index, vjezba) in item.vjezbe.withIndex()) {
                        sb.append("   S${index + 1}: ${vjezba.broj_ponavljanja} pon. @ ${vjezba.tezina} kg\n")
                    }
                    sb.append("\n")
                }
            }

            withContext(Dispatchers.Main) {
                tvPodaci.text = sb.toString()
            }
        }
    }
}