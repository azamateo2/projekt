package ba.sum.fsre.aplikacijazagym

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PovijestActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_povijest)


        val kontejner = findViewById<LinearLayout>(R.id.kontejnerPovijest)
        val btnNazad = findViewById<Button>(R.id.btnNazad)
        val korisnikId = intent.getIntExtra("KORISNIK_ID", -1)

        btnNazad.setOnClickListener {
            finish()
        }

        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "moj_trening_db").build()
        val repository = FitnessRepository(db)

        lifecycleScope.launch(Dispatchers.IO) {
            val listaTreninga = repository.dohvatiSveTreningeKorisnika(korisnikId)
            val katalog = repository.dohvatiKatalog()

            withContext(Dispatchers.Main) {
                kontejner.removeAllViews()

                if (listaTreninga.isEmpty()) {
                    val tvPrazno = TextView(this@PovijestActivity)
                    tvPrazno.text = "Još nemaš spremljenih treninga. Kreni na posao! 💪"
                    tvPrazno.setTextColor(Color.GRAY)
                    tvPrazno.gravity = Gravity.CENTER
                    tvPrazno.setPadding(0, 50, 0, 0)
                    kontejner.addView(tvPrazno)
                } else {
                    var posljednjiDatum = ""

                    for (item in listaTreninga) {

                        if (item.trening.datum != posljednjiDatum) {
                            val tvDatum = TextView(this@PovijestActivity)
                            tvDatum.text = "\n📅 DATUM: ${item.trening.datum}"
                            tvDatum.setTextColor(resources.getColor(R.color.gym_accent))
                            tvDatum.textSize = 18f
                            tvDatum.setTypeface(null, android.graphics.Typeface.BOLD)
                            kontejner.addView(tvDatum)

                            val linija = View(this@PovijestActivity)
                            linija.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2)
                            linija.setBackgroundColor(Color.parseColor("#444444"))
                            kontejner.addView(linija)

                            posljednjiDatum = item.trening.datum
                        }


                        val grupiraneVjezbe = item.vjezbe.groupBy { it.katalog_id }

                        for ((katId, vjezbe) in grupiraneVjezbe) {
                            val stavkaIzKataloga = katalog.find { it.katalog_id == katId }
                            val nazivVjezbe = stavkaIzKataloga?.naziv_vjezbe ?: "Nepoznata vježba"
                            val opisVjezbe = stavkaIzKataloga?.opis ?: ""


                            for ((index, vjezba) in vjezbe.withIndex()) {
                                val tvStavka = TextView(this@PovijestActivity)
                                val sb = StringBuilder()

                                if (index == 0) {
                                    sb.append("🏋️ $nazivVjezbe\n")
                                    if (opisVjezbe.isNotEmpty()) sb.append("   📝 $opisVjezbe\n")
                                }

                                sb.append("   Set ${index + 1}:  ${vjezba.broj_ponavljanja} x ${vjezba.tezina} kg")

                                tvStavka.text = sb.toString()
                                tvStavka.setTextColor(Color.WHITE)
                                tvStavka.textSize = 16f
                                tvStavka.setPadding(20, 15, 20, 15)


                                tvStavka.setOnLongClickListener {
                                    AlertDialog.Builder(this@PovijestActivity)
                                        .setTitle("Brisanje zapisa")
                                        .setMessage("Želiš li obrisati ovu seriju?")
                                        .setPositiveButton("DA") { _, _ ->
                                            lifecycleScope.launch(Dispatchers.IO) {
                                                repository.obrisiJednuVjezbu(vjezba.sifra) // Koristimo 'sifra'
                                                withContext(Dispatchers.Main) {
                                                    Toast.makeText(this@PovijestActivity, "Obrisano!", Toast.LENGTH_SHORT).show()
                                                    recreate()
                                                }
                                            }
                                        }
                                        .setNegativeButton("NE", null)
                                        .show()
                                    true
                                }


                                tvStavka.setOnClickListener {
                                    val prozor = AlertDialog.Builder(this@PovijestActivity)
                                    prozor.setTitle("Uredi seriju")


                                    val layout = LinearLayout(this@PovijestActivity)
                                    layout.orientation = LinearLayout.VERTICAL
                                    layout.setPadding(50, 20, 50, 20)

                                    val inputPonavljanja = EditText(this@PovijestActivity)
                                    inputPonavljanja.hint = "Ponavljanja"
                                    inputPonavljanja.setText(vjezba.broj_ponavljanja.toString())
                                    inputPonavljanja.inputType = android.text.InputType.TYPE_CLASS_NUMBER
                                    layout.addView(inputPonavljanja)

                                    val inputTezina = EditText(this@PovijestActivity)
                                    inputTezina.hint = "Težina (kg)"
                                    inputTezina.setText(vjezba.tezina.toString())
                                    inputTezina.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                                    layout.addView(inputTezina)

                                    prozor.setView(layout)

                                    prozor.setPositiveButton("SPREMI") { _, _ ->
                                        val novoP = inputPonavljanja.text.toString().toIntOrNull() ?: vjezba.broj_ponavljanja
                                        val novoT = inputTezina.text.toString().toDoubleOrNull() ?: vjezba.tezina

                                        lifecycleScope.launch(Dispatchers.IO) {
                                            // Kreiramo kopiju vježbe s novim podacima (sifra ostaje ista!)
                                            val azuriranaVjezba = vjezba.copy(broj_ponavljanja = novoP, tezina = novoT)
                                            repository.azurirajVjezbu(azuriranaVjezba)

                                            withContext(Dispatchers.Main) {
                                                Toast.makeText(this@PovijestActivity, "Ažurirano!", Toast.LENGTH_SHORT).show()
                                                recreate() // Osvježi ekran da se vide nove brojke
                                            }
                                        }
                                    }
                                    prozor.setNegativeButton("ODUSTANI", null)
                                    prozor.show()
                                }

                                kontejner.addView(tvStavka)
                            }


                            val razmak = View(this@PovijestActivity)
                            razmak.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
                            razmak.setBackgroundColor(Color.parseColor("#222222"))
                            kontejner.addView(razmak)
                        }
                    }
                }
            }
        }
    }
}