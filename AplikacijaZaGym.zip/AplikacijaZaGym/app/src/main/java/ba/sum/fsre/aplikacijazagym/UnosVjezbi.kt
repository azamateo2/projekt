package ba.sum.fsre.aplikacijazagym

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class UnosVjezbeActivity : AppCompatActivity() {

    private val listaSerijaInputa = mutableListOf<Pair<EditText, EditText>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_unos_vjezbi)

        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "moj_trening_db").build()
        val repository = FitnessRepository(db)

        val korisnikId = intent.getIntExtra("KORISNIK_ID", -1)
        val spiner = findViewById<Spinner>(R.id.spinerVjezbe)
        val etNovaVjezba = findViewById<EditText>(R.id.etNovaVjezba)
        val etOpisVjezbe = findViewById<EditText>(R.id.etOpisVjezbe) // DODANO POLJE ZA OPIS
        val containerSerije = findViewById<LinearLayout>(R.id.containerSerije)
        val btnDodajSeriju = findViewById<Button>(R.id.btnDodajSeriju)
        val btnSpremi = findViewById<Button>(R.id.btnSpremiVjezbu)

        fun dodajNoviRedSerije() {
            val red = LinearLayout(this)
            red.orientation = LinearLayout.HORIZONTAL
            red.setPadding(0, 10, 0, 10)
            red.gravity = Gravity.CENTER_VERTICAL

            val tvBroj = TextView(this)
            tvBroj.text = "${listaSerijaInputa.size + 1}."
            tvBroj.setTextColor(resources.getColor(R.color.gym_accent))
            tvBroj.textSize = 18f
            tvBroj.setPadding(10, 0, 20, 0)


            val etPonavljanja = EditText(ContextThemeWrapper(this, R.style.GymInputStyle), null, 0)
            etPonavljanja.hint = "Reps"
            etPonavljanja.inputType = InputType.TYPE_CLASS_NUMBER
            etPonavljanja.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)


            etPonavljanja.isFocusable = true
            etPonavljanja.isFocusableInTouchMode = true
            etPonavljanja.isClickable = true
            etPonavljanja.isEnabled = true


            val etTezina = EditText(ContextThemeWrapper(this, R.style.GymInputStyle), null, 0)
            etTezina.hint = "Kg"
            etTezina.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            etTezina.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)


            etTezina.isFocusable = true
            etTezina.isFocusableInTouchMode = true
            etTezina.isClickable = true
            etTezina.isEnabled = true

            red.addView(tvBroj)
            red.addView(etPonavljanja)
            red.addView(etTezina)
            containerSerije.addView(red)

            listaSerijaInputa.add(Pair(etPonavljanja, etTezina))
        }

        dodajNoviRedSerije()
        btnDodajSeriju.setOnClickListener { dodajNoviRedSerije() }


        lifecycleScope.launch(Dispatchers.IO) {
            val vjezbeIzKataloga = repository.dohvatiKatalog()
            val naziviVjezbi = vjezbeIzKataloga.map { it.naziv_vjezbe }

            withContext(Dispatchers.Main) {
                val adapter = object : ArrayAdapter<String>(
                    this@UnosVjezbeActivity,
                    android.R.layout.simple_spinner_item,
                    naziviVjezbi
                ) {
                    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                        val v = super.getView(position, convertView, parent)
                        (v as TextView).setTextColor(Color.WHITE)
                        v.textSize = 16f
                        return v
                    }

                    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                        val v = super.getDropDownView(position, convertView, parent)
                        v.setBackgroundColor(Color.parseColor("#1E1E1E"))
                        (v as TextView).setTextColor(Color.WHITE)
                        return v
                    }
                }
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spiner.adapter = adapter
            }
        }

        btnSpremi.setOnClickListener {
            val novaVjezbaNaziv = etNovaVjezba.text.toString().trim()
            val opisVjezbe = etOpisVjezbe.text.toString().trim() // DOHVATI OPIS
            val odabranaIzSpinera = spiner.selectedItem?.toString()

            if (novaVjezbaNaziv.isEmpty() && odabranaIzSpinera == null) {
                Toast.makeText(this, "Odaberi vježbu ili unesi novi naziv!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val validneSerije = listaSerijaInputa.filter { pair ->
                pair.first.text.toString().trim().isNotEmpty() &&
                        pair.second.text.toString().trim().isNotEmpty()
            }

            if (validneSerije.isEmpty()) {
                Toast.makeText(this, "Moraš unijeti barem jednu seriju!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch(Dispatchers.IO) {
                var konacniKatalogId = -1

                if (novaVjezbaNaziv.isNotEmpty()) {

                    repository.dodajUKatalog(KatalogVjezbi(naziv_vjezbe = novaVjezbaNaziv, opis = opisVjezbe))
                    konacniKatalogId = repository.dohvatiKatalog().find { it.naziv_vjezbe == novaVjezbaNaziv }?.katalog_id ?: -1
                } else {
                    konacniKatalogId = repository.dohvatiKatalog().find { it.naziv_vjezbe == odabranaIzSpinera }?.katalog_id ?: -1
                }

                if (konacniKatalogId != -1) {
                    val datum = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
                    val treningId = repository.zapocniTrening(Trening(datum = datum, tip_treninga = "Snaga", korisnik_id = korisnikId))

                    for (serijaInput in validneSerije) {
                        val p = serijaInput.first.text.toString().toInt()
                        val t = serijaInput.second.text.toString().toDouble()

                        repository.spremiVjezbuUTrening(VjezbaUTreningu(
                            trening_id = treningId.toInt(),
                            katalog_id = konacniKatalogId,
                            broj_serija = 1,
                            broj_ponavljanja = p,
                            tezina = t
                        ))
                    }

                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@UnosVjezbeActivity, "Trening spremljen!", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }
        }
    }
}