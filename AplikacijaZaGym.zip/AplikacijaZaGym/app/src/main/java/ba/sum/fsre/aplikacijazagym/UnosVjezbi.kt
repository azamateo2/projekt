package ba.sum.fsre.aplikacijazagym

import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class UnosVjezbeActivity : AppCompatActivity() {

    private val listaSerijaInputa = mutableListOf<Pair<EditText, EditText>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_unos_vjezbi)

        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "moj_trening_db").build()
        val repository = FitnessRepository(db)

        val korisnikId = intent.getIntExtra("KORISNIK_ID", -1)
        val spiner = findViewById<Spinner>(R.id.spinerVjezbe)
        val etNovaVjezba = findViewById<EditText>(R.id.etNovaVjezba)
        val containerSerije = findViewById<LinearLayout>(R.id.containerSerije)
        val btnDodajSeriju = findViewById<Button>(R.id.btnDodajSeriju)
        val btnSpremi = findViewById<Button>(R.id.btnSpremiVjezbu)

        // Funkcija za dinamičko dodavanje reda za seriju
        fun dodajNoviRedSerije() {
            val red = LinearLayout(this)
            red.orientation = LinearLayout.HORIZONTAL
            red.setPadding(0, 5, 0, 5)

            val etPonavljanja = EditText(this)
            etPonavljanja.hint = "Ponavljanja"
            etPonavljanja.inputType = InputType.TYPE_CLASS_NUMBER
            etPonavljanja.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            etPonavljanja.setTextColor(android.graphics.Color.WHITE)

            val etTezina = EditText(this)
            etTezina.hint = "Kg"
            etTezina.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            etTezina.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            etTezina.setTextColor(android.graphics.Color.WHITE)

            red.addView(etPonavljanja)
            red.addView(etTezina)
            containerSerije.addView(red)

            listaSerijaInputa.add(Pair(etPonavljanja, etTezina))
        }

        // Dodaj prvu seriju automatski
        dodajNoviRedSerije()

        btnDodajSeriju.setOnClickListener { dodajNoviRedSerije() }

        // Učitavanje vježbi u Spinner
        lifecycleScope.launch(Dispatchers.IO) {
            val vjezbeIzKataloga = repository.dohvatiKatalog()
            val naziviVjezbi = vjezbeIzKataloga.map { it.naziv_vjezbe }
            withContext(Dispatchers.Main) {
                val adapter = ArrayAdapter(this@UnosVjezbeActivity, android.R.layout.simple_spinner_item, naziviVjezbi)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spiner.adapter = adapter
            }
        }

        btnSpremi.setOnClickListener {
            val novaVjezbaNaziv = etNovaVjezba.text.toString().trim()

            lifecycleScope.launch(Dispatchers.IO) {
                var konacniKatalogId = -1

                if (novaVjezbaNaziv.isNotEmpty()) {
                    repository.dodajUKatalog(KatalogVjezbi(naziv_vjezbe = novaVjezbaNaziv, opis = ""))
                    konacniKatalogId = repository.dohvatiKatalog().find { it.naziv_vjezbe == novaVjezbaNaziv }?.katalog_id ?: -1
                } else {
                    val odabrana = spiner.selectedItem?.toString()
                    konacniKatalogId = repository.dohvatiKatalog().find { it.naziv_vjezbe == odabrana }?.katalog_id ?: -1
                }

                if (konacniKatalogId != -1) {
                    val datum = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
                    val treningId = repository.zapocniTrening(Trening(datum = datum, tip_treninga = "Snaga", korisnik_id = korisnikId))

                    // Spremanje svake serije kao poseban zapis
                    for (serijaInput in listaSerijaInputa) {
                        val p = serijaInput.first.text.toString().toIntOrNull() ?: 0
                        val t = serijaInput.second.text.toString().toDoubleOrNull() ?: 0.0

                        if (p > 0) { // Spremi samo ako su unesena ponavljanja
                            repository.spremiVjezbuUTrening(VjezbaUTreningu(
                                trening_id = treningId.toInt(),
                                katalog_id = konacniKatalogId,
                                broj_serija = 1,
                                broj_ponavljanja = p,
                                tezina = t
                            ))
                        }
                    }

                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@UnosVjezbeActivity, "Trening uspješno spremljen!", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }
        }
    }
}