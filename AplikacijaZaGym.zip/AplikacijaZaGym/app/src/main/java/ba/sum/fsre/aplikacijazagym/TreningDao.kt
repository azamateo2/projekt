package ba.sum.fsre.aplikacijazagym

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface TreningDao {

    @Insert
    suspend fun insert(trening: Trening): Long


    @Query("SELECT * FROM trening WHERE korisnik_id = :korisnikId")
    suspend fun getTreninziZaKorisnika(korisnikId: Int): List<Trening>


    @Transaction
    @Query("SELECT * FROM trening WHERE korisnik_id = :korisnikId ORDER BY trening_id DESC")
    suspend fun getSveZaKorisnika(korisnikId: Int): List<TreningSaVjezbama>
}