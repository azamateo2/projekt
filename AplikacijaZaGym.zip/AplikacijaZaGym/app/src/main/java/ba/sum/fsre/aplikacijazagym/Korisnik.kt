package ba.sum.fsre.aplikacijazagym

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "korisnik")
data class Korisnik(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "korisnik_id")
    val id: Int = 0,

    val ime: String,
    val prezime: String
)
