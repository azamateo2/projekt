package ba.sum.fsre.aplikacijazagym

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface VjezbaUTreninguDao {

    @Insert
    fun insert(vjezba: VjezbaUTreningu)

    @Query("SELECT * FROM vjezba_u_treningu WHERE trening_id = :treningId")
    fun getVjezbeZaTrening(treningId: Int): List<VjezbaUTreningu>

    @Query("DELETE FROM vjezba_u_treningu WHERE sifra = :id")
    suspend fun obrisiVjezbuPoId(id: Int)

    @Update
    suspend fun azurirajVjezbu(vjezba: VjezbaUTreningu)
}
