package ba.sum.fsre.aplikacijazagym

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface VjezbaUTreninguDao {

    @Insert
    fun insert(vjezba: VjezbaUTreningu)

    @Query("SELECT * FROM vjezba_u_treningu WHERE trening_id = :treningId")
    fun getVjezbeZaTrening(treningId: Int): List<VjezbaUTreningu>
}
