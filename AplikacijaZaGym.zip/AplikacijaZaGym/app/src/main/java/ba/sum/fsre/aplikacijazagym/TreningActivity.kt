package ba.sum.fsre.aplikacijazagym

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TreningActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_trening)


        val korisnikId = intent.getIntExtra("KORISNIK_ID", -1)
        val ime = intent.getStringExtra("KORISNIK_IME")


        val tvDobrodosao = findViewById<TextView>(R.id.tvDobrodosao)
        val btnNoviTrening = findViewById<TextView>(R.id.btnNoviTrening)
        val btnPregledPovijesti = findViewById<TextView>(R.id.btnPregledTreninga)


        tvDobrodosao.text = "Dobrodošao, $ime!"


        btnNoviTrening.setOnClickListener {
            val intent = Intent(this, UnosVjezbeActivity::class.java)
            intent.putExtra("KORISNIK_ID", korisnikId)
            startActivity(intent)
        }

        btnPregledPovijesti.setOnClickListener {
            val intent = Intent(this, PovijestActivity::class.java)
            intent.putExtra("KORISNIK_ID", korisnikId)
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            startActivity(intent)
        }
    }
}