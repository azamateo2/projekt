package ba.sum.fsre.aplikacijazagym

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "katalog_vjezbi")
data class KatalogVjezbi(
    @PrimaryKey(autoGenerate = true)
    val katalog_id: Int = 0,
    val naziv_vjezbe: String,
    val opis: String
)
